from django.shortcuts import render
from django.core.mail import send_mail
from .models import Project, Skill, Testimonial
# core/views.py

def home(request):
    skills = Skill.objects.all()
    testimonials = Testimonial.objects.all()
    return render(request, 'home.html', {
        'skills': skills,
        'testimonials': testimonials
    })

def contact(request):
    success = False
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        full_message = f"Message from {name} ({email}):\n\n{message}"

        send_mail(
            subject=f"Portfolio Contact from {name}",
            message=full_message,
            from_email=None,
            recipient_list=['your_email@example.com'],  # change to your real email
        )

        success = True

    return render(request, 'contact.html', {'success': success})

def projects(request):
    all_projects = Project.objects.all()
    return render(request, 'projects.html', {'projects': all_projects})

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'services.html')