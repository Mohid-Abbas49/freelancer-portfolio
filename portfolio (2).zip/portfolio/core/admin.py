from django.contrib import admin
from .models import Project, Skill, Testimonial  # Add these

admin.site.register(Project)
admin.site.register(Skill)
admin.site.register(Testimonial)
