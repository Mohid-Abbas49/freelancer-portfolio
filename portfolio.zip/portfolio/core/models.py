# core/models.py

from django.db import models

class Skill(models.Model):
    name = models.CharField(max_length=100)
    proficiency = models.PositiveIntegerField(help_text="Value between 1 and 100")

    def __str__(self):
        return f"{self.name} - {self.proficiency}%"

class Testimonial(models.Model):
    client_name = models.CharField(max_length=100)
    feedback = models.TextField()
    image = models.ImageField(upload_to='testimonials/', blank=True, null=True)

    def __str__(self):
        return self.client_name

class Project(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='projects/')
    demo_link = models.URLField(blank=True)

    def __str__(self):
        return self.title
